package Bobtail.Assignment.Bobtail.Assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class Fixedamountoffcases {
	
	
	

	//This test case is to calculate the price with "Fixed Amount off" Method with input values of price before discount and discount.
	@Test
	public void fixedoff1() throws InterruptedException {
		
		
		new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(Locators.clear)));
		Configuration.driver.findElement(By.cssSelector(Locators.clear)).click();
		new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.pricebeforediscount)));
		Configuration.driver.findElement(By.xpath(Locators.pricebeforediscount)).sendKeys("60");
		Thread.sleep(3000);
		new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.id(Locators.discount)));
		Configuration.driver.findElement(By.id(Locators.discount)).sendKeys("15");
		Thread.sleep(5000);
		new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.fixedamountoff)));
		Configuration.driver.findElement(By.xpath(Locators.fixedamountoff)).click();;
		Thread.sleep(5000);
		new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.calculate)));
		Configuration.driver.findElement(By.xpath(Locators.calculate)).click();
		
		
	}
		
		
		
		//This test case is to calculate the price with "Fixed Amount off" Method with input values of price before discount and price after discount.
				@Test
				public void fixedoff3() throws InterruptedException {
					
					
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(Locators.clear)));
					Configuration.driver.findElement(By.cssSelector(Locators.clear)).click();
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.pricebeforediscount)));
					Configuration.driver.findElement(By.xpath(Locators.pricebeforediscount)).sendKeys("60");
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.priceafterdiscount)));
					Configuration.driver.findElement(By.xpath(Locators.priceafterdiscount)).sendKeys("15");
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.fixedamountoff)));
					Configuration.driver.findElement(By.xpath(Locators.fixedamountoff)).click();;
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.calculate)));
					Configuration.driver.findElement(By.xpath(Locators.calculate)).click();	
				
				
				
				
				
			}
				
				//This test case is to calculate the price with "Fixed Amount off" Method with input values of price after discount and only discount.
				@Test
				public void fixedoff4() throws InterruptedException {
					
					
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(Locators.clear)));
					Configuration.driver.findElement(By.cssSelector(Locators.clear)).click();
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.id(Locators.discount)));
					Configuration.driver.findElement(By.id(Locators.discount)).sendKeys("60");
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.priceafterdiscount)));
					Configuration.driver.findElement(By.xpath(Locators.priceafterdiscount)).sendKeys("15");
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.fixedamountoff)));
					Configuration.driver.findElement(By.xpath(Locators.fixedamountoff)).click();;
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.calculate)));
					Configuration.driver.findElement(By.xpath(Locators.calculate)).click();	
				
				
				
				
				
			}
		
				//This negative test case is to give error if i enter only one value and try to calculate it.
				@Test
				public void fixedoff5() throws InterruptedException {
					
					
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(Locators.clear)));
					Configuration.driver.findElement(By.cssSelector(Locators.clear)).click();
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.id(Locators.discount)));
					Configuration.driver.findElement(By.id(Locators.discount)).sendKeys("60");
					
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.fixedamountoff)));
					Configuration.driver.findElement(By.xpath(Locators.fixedamountoff)).click();;
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.calculate)));
					Configuration.driver.findElement(By.xpath(Locators.calculate)).click();	
				
				
				
				
				
			}
				
						

		
		@AfterTest
		public void quit() {
			
			Configuration.driver.quit();
			
		}
	

}
