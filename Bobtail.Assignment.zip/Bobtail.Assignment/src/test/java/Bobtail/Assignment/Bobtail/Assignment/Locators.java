package Bobtail.Assignment.Bobtail.Assignment;

public class Locators {

	
	public static String gettext = "/html[1]/body[1]/div[3]/div[1]/h1[1]";
	public static String pricebeforediscount = "/html[1]/body[1]/div[3]/div[1]/form[1]/table[1]/tbody[1]/tr[1]/td[2]/input[1]";
	public static String discount = "discountinput";
	public static String priceafterdiscount = "/html[1]/body[1]/div[3]/div[1]/form[1]/table[1]/tbody[1]/tr[3]/td[2]/input[1]";
	public static String yousaved = "#savedamountinput";
	public static String percentoff = "/html[1]/body[1]/div[3]/div[1]/form[1]/table[1]/tbody[1]/tr[5]/td[1]/table[1]/tbody[1]/tr[1]/td[2]/div[1]/label[1]";
	public static String fixedamountoff = "/html[1]/body[1]/div[3]/div[1]/form[1]/table[1]/tbody[1]/tr[5]/td[1]/table[1]/tbody[1]/tr[1]/td[2]/div[2]/label[1]";
	public static String calculate = "/html[1]/body[1]/div[3]/div[1]/form[1]/table[1]/tbody[1]/tr[6]/td[1]/table[1]/tbody[1]/tr[1]/td[1]/input[1]";
	public static String clear = ".clearbtn";
	public static String discountdisplay = "p:nth-child(2) font:nth-child(1) b:nth-child(1)";
	
	
	
	
	
	
	
}
