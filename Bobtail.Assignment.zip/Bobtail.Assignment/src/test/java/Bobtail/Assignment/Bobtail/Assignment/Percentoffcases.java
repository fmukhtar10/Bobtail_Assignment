package Bobtail.Assignment.Bobtail.Assignment;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;




import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;




public class Percentoffcases {
	
	
	
	

	//This test case is to calculate the price with "Percent off" Method with input values of price before discount and discount.
	@Test
	public void percentoff1() throws InterruptedException {
		
		
		new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(Locators.clear)));
		Configuration.driver.findElement(By.cssSelector(Locators.clear)).click();
		new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.pricebeforediscount)));
		Configuration.driver.findElement(By.xpath(Locators.pricebeforediscount)).sendKeys("60");
		Thread.sleep(3000);
		new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.id(Locators.discount)));
		Configuration.driver.findElement(By.id(Locators.discount)).sendKeys("15");
		Thread.sleep(5000);
		new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.percentoff)));
		Configuration.driver.findElement(By.xpath(Locators.percentoff)).click();;
		Thread.sleep(5000);
		new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.calculate)));
		Configuration.driver.findElement(By.xpath(Locators.calculate)).click();
		
		
	}
		
		//This test case is to calculate the price with "Percent off" Method with input values of price before discount and you saved value.
		@Test
		public void percentoff2() throws InterruptedException {
			
			
			new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(Locators.clear)));
			Configuration.driver.findElement(By.cssSelector(Locators.clear)).click();
			new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.pricebeforediscount)));
			Configuration.driver.findElement(By.xpath(Locators.pricebeforediscount)).sendKeys("60");
			Thread.sleep(3000);
			new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(Locators.yousaved)));
			Configuration.driver.findElement(By.cssSelector(Locators.yousaved)).sendKeys("15");
			Thread.sleep(3000);
			new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.percentoff)));
			Configuration.driver.findElement(By.xpath(Locators.percentoff)).click();;
			Thread.sleep(3000);
			new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.calculate)));
			Configuration.driver.findElement(By.xpath(Locators.calculate)).click();	
		
		
		
		
		
	}
		
		//This test case is to calculate the price with "Percent off" Method with input values of price before discount and price after discount.
				@Test
				public void percentoff3() throws InterruptedException {
					
					
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(Locators.clear)));
					Configuration.driver.findElement(By.cssSelector(Locators.clear)).click();
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.pricebeforediscount)));
					Configuration.driver.findElement(By.xpath(Locators.pricebeforediscount)).sendKeys("60");
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.priceafterdiscount)));
					Configuration.driver.findElement(By.xpath(Locators.priceafterdiscount)).sendKeys("15");
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.percentoff)));
					Configuration.driver.findElement(By.xpath(Locators.percentoff)).click();;
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.calculate)));
					Configuration.driver.findElement(By.xpath(Locators.calculate)).click();	
				
				
				
				
				
			}
				
				//This test case is to calculate the price with "Percent off" Method with input values of price after discount and only discount.
				@Test
				public void percentoff4() throws InterruptedException {
					
					
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(Locators.clear)));
					Configuration.driver.findElement(By.cssSelector(Locators.clear)).click();
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.id(Locators.discount)));
					Configuration.driver.findElement(By.id(Locators.discount)).sendKeys("60");
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.priceafterdiscount)));
					Configuration.driver.findElement(By.xpath(Locators.priceafterdiscount)).sendKeys("15");
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.percentoff)));
					Configuration.driver.findElement(By.xpath(Locators.percentoff)).click();;
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.calculate)));
					Configuration.driver.findElement(By.xpath(Locators.calculate)).click();	
				
				
				
				
				
			}
		
				//This test case is to calculate the price with "Percent off" Method with input values of you saved and only discount.
				@Test
				public void percentoff5() throws InterruptedException {
					
					
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(Locators.clear)));
					Configuration.driver.findElement(By.cssSelector(Locators.clear)).click();
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.id(Locators.discount)));
					Configuration.driver.findElement(By.id(Locators.discount)).sendKeys("60");
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(Locators.yousaved)));
					Configuration.driver.findElement(By.cssSelector(Locators.yousaved)).sendKeys("15");
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.percentoff)));
					Configuration.driver.findElement(By.xpath(Locators.percentoff)).click();;
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.calculate)));
					Configuration.driver.findElement(By.xpath(Locators.calculate)).click();	
				
				
				
				
				
			}
				
				//This test case is to calculate the price with "Percent off" Method with input values of you saved and price after discount.
				@Test
				public void percentoff6() throws InterruptedException {
					
					
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(Locators.clear)));
					Configuration.driver.findElement(By.cssSelector(Locators.clear)).click();
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.priceafterdiscount)));
					Configuration.driver.findElement(By.xpath(Locators.priceafterdiscount)).sendKeys("15");
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(Locators.yousaved)));
					Configuration.driver.findElement(By.cssSelector(Locators.yousaved)).sendKeys("15");
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.percentoff)));
					Configuration.driver.findElement(By.xpath(Locators.percentoff)).click();;
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.calculate)));
					Configuration.driver.findElement(By.xpath(Locators.calculate)).click();	
				
				
				
				
				
			}
				//This negative test case is to give if i try to calculate discount with only one value.
				@Test
				public void percentoff7() throws InterruptedException {
					
					
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(Locators.clear)));
					Configuration.driver.findElement(By.cssSelector(Locators.clear)).click();
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.priceafterdiscount)));
					Configuration.driver.findElement(By.xpath(Locators.priceafterdiscount)).sendKeys("15");
					
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.percentoff)));
					Configuration.driver.findElement(By.xpath(Locators.percentoff)).click();;
					Thread.sleep(3000);
					new WebDriverWait(Configuration.driver,20).until(ExpectedConditions.presenceOfElementLocated(By.xpath(Locators.calculate)));
					Configuration.driver.findElement(By.xpath(Locators.calculate)).click();	
				
				
				
				
				
			}			
		
	
	
	
	
	

}
