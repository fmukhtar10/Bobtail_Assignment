package Bobtail.Assignment.Bobtail.Assignment;

import org.testng.AssertJUnit;
import org.testng.annotations.Test;

public class Gettitle {

	//This test case if to verify if we're on the right web URL or not.
			@Test
			public void gettitle() throws InterruptedException {
				
				
				String expectedtitle = "Discount Calculator";
				String actualtitle = Configuration.driver.getTitle();
				AssertJUnit.assertEquals(actualtitle, expectedtitle);
				Thread.sleep(5000);
			}
	
	
}
